# 컴포넌트 이해하기

해당 소스는 [짐코딩 GYMCODING](https://www.youtube.com/channel/UCZ30aWiMw5C8mGcESlAGQbA/?sub_confirmation=1) "Vue3 완벽 바이블 - 기초부터 실전까지" 강좌의 "컴포넌트이해하기" 편에 사용된 자료 입니다.

## Installation

```bash
git clone https://github.com/gymcoding/vue3-getting-started.git
```

```bash
cd vue3-getting-started
npm install
npm run dev
```

## License

[MIT](https://choosealicense.com/licenses/mit/)
