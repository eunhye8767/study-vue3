<template>
  <header>
    <h1>header</h1>
  </header>
</template>
<script>
export default {};
</script>
<style></style>
