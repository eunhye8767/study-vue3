<template>
  <article class="book">
    <div class="book_subtitle">제목</div>
    <div class="book__title">HTML 강좌</div>
  </article>
</template>
<script>
export default {};
</script>
<style></style>
