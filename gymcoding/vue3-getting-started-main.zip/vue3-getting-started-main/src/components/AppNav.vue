<template>
  <nav>
    <h2>nav</h2>
    <ul>
      <li><a href="#">메뉴1</a></li>
      <li><a href="#">메뉴2</a></li>
      <li><a href="#">메뉴3</a></li>
      <li><a href="#">메뉴4</a></li>
    </ul>
  </nav>
</template>
<script>
export default {};
</script>
<style></style>
